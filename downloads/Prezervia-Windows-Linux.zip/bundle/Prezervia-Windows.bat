@echo off
start "" "%~dp0Prezervia.html"
