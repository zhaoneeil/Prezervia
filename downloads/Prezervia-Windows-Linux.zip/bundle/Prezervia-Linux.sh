#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
xdg-open "$DIR/Prezervia.html" 2>/dev/null || sensible-browser "$DIR/Prezervia.html"
