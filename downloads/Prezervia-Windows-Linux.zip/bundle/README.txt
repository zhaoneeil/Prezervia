Prezervia — animal vital tracker
================================

This app works offline on any device. Nothing to install.

WINDOWS:  double-click  Prezervia-Windows.bat
LINUX:    double-click  Prezervia-Linux.sh   (or: run it in a terminal)
ANY DEVICE (Mac, phone, tablet): open Prezervia.html in any web browser.

Your pets are saved in the browser on that device.
This app shows recorded data only. It does not diagnose — that is the vet's job.
